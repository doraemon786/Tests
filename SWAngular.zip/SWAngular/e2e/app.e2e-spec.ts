import { SWAngularPage } from './app.po';

describe('swangular App', function() {
  let page: SWAngularPage;

  beforeEach(() => {
    page = new SWAngularPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
